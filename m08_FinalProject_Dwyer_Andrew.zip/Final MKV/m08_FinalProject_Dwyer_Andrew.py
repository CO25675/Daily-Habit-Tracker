# SDEV1140 Final Project - Habit Tracker
# author: Andrew Dwyer
# created: 2024-11-24  updated: 2024-11-24 (AD)
# A user-friendly habit tracker application to log and track daily habits with enhanced features.

# Pseudo-code:
# 1. Create a visually appealing main window with navigation buttons (Add Habit, View Progress, Settings).
# 2. Add a feature to log habits with a name and weekly frequency.
# 3. Store habits in memory and enable users to mark habits as completed.
# 4. Add progress tracking and display it in the View Progress window.
# 5. Implement a settings window for customization (e.g., notifications).
# 6. Ensure consistent styling and intuitive user interactions.

import tkinter as tk
from tkinter import messagebox, Toplevel
import json
import os

# Constants
BACKGROUND_COLOR = "#1e1e2f"
TEXT_COLOR = "#00d1b2"
BUTTON_COLOR = "#29293d"
BUTTON_TEXT_COLOR = "#ffffff"
DATA_FILE = "habits_data.json"
SETTINGS_FILE = "settings_data.json"
IMAGE_FOLDER_PATH = "/Users/andydwyer/Desktop/Final MKV"  # Path to images

# Global dictionaries to store habits and settings
habits = {}
settings = {
    "reminder_enabled": False,
    "notification_frequency": "daily",
}

# Load habits from file if it exists
def load_habits():
    """Load habits from a JSON file to maintain persistence."""
    global habits
    try:
        with open(DATA_FILE, "r") as file:
            habits = json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        habits = {}

# Save habits to file
def save_habits():
    """Save habits to a JSON file for persistence."""
    with open(DATA_FILE, "w") as file:
        json.dump(habits, file, indent=4)

# Function to create a styled button
def create_button(parent, text, command, width=20):
    """Create a styled button with consistent theme and active states."""
    button = tk.Button(
        parent,
        text=text,
        command=command,
        font=("Helvetica", 12),
        bg=BUTTON_COLOR,
        fg=BUTTON_TEXT_COLOR,
        activebackground=BUTTON_COLOR,
        activeforeground=TEXT_COLOR,
        relief="flat",
        width=width,
    )
    add_hover_effects(button, TEXT_COLOR, BUTTON_COLOR)
    return button

# Add hover effects to a button
def add_hover_effects(button, hover_bg, hover_fg):
    """Add hover effects to a button for better feedback."""
    def on_enter(e):
        button["bg"] = hover_bg
        button["fg"] = hover_fg

    def on_leave(e):
        button["bg"] = BUTTON_COLOR
        button["fg"] = BUTTON_TEXT_COLOR

    button.bind("<Enter>", on_enter)
    button.bind("<Leave>", on_leave)

# Create the main application window
def create_main_window():
    """Create and display the main application window."""
    main_window = tk.Tk()
    main_window.title("Daily Habit Tracker")
    main_window.geometry("600x400")
    main_window.config(bg=BACKGROUND_COLOR)

    # Title Label
    tk.Label(
        main_window,
        text="Daily Habit Tracker",
        font=("Helvetica", 20, "bold"),
        bg=BACKGROUND_COLOR,
        fg=TEXT_COLOR,
    ).pack(pady=20)

    # Load and display Running1.png on main window
    image_path = os.path.join(IMAGE_FOLDER_PATH, "Running1.png")
    if os.path.exists(image_path):
        img = tk.PhotoImage(file=image_path)
        img = img.subsample(8, 8)  # Resize to 1/8 of the original size

        # Label to display the image
        img_label = tk.Label(main_window, image=img, bg=BACKGROUND_COLOR)
        img_label.image = img  # Store a reference to avoid garbage collection
        img_label.pack(pady=20)

    # Navigation Buttons
    create_button(main_window, "Add Habit", open_add_habit_window).pack(pady=10)
    create_button(main_window, "View Progress", open_progress_window).pack(pady=10)
    create_button(main_window, "Settings", open_settings_window).pack(pady=10)
    create_button(main_window, "Exit", main_window.quit).pack(pady=20)

    # Load saved habits and settings
    load_habits()
    main_window.mainloop()

# Open the Add Habit window
def open_add_habit_window():
    """Open a window to add a new habit."""
    add_habit_window = Toplevel()
    add_habit_window.title("Add New Habit")
    add_habit_window.geometry("400x300")
    add_habit_window.config(bg=BACKGROUND_COLOR)

    # Habit Name Entry
    tk.Label(
        add_habit_window, text="Habit Name:", font=("Helvetica", 12), bg=BACKGROUND_COLOR, fg=TEXT_COLOR
    ).pack(pady=10)
    habit_name_entry = tk.Entry(add_habit_window, font=("Helvetica", 12))
    habit_name_entry.pack(pady=5)

    # Frequency Entry
    tk.Label(
        add_habit_window, text="Frequency (1-7 times per week):", font=("Helvetica", 12), bg=BACKGROUND_COLOR, fg=TEXT_COLOR
    ).pack(pady=10)
    frequency_entry = tk.Entry(add_habit_window, font=("Helvetica", 12))
    frequency_entry.pack(pady=5)

    # Save Habit Button
    create_button(
        add_habit_window,
        "Save Habit",
        lambda: save_habit(habit_name_entry.get(), frequency_entry.get(), add_habit_window),
    ).pack(pady=20)

# Save the habit with validation
def save_habit(habit_name, frequency, window):
    """Validate and save a new habit."""
    if not habit_name.strip():
        messagebox.showwarning("Input Error", "Please enter a habit name.")
        return
    try:
        frequency = int(frequency)
        if 1 <= frequency <= 7:
            habits[habit_name] = {"frequency": frequency, "completed": []}
            save_habits()
            messagebox.showinfo("Success", f"Habit '{habit_name}' added successfully.")
            window.destroy()
        else:
            messagebox.showwarning("Input Error", "Frequency must be between 1 and 7.")
    except ValueError:
        messagebox.showwarning("Input Error", "Please enter a valid number for frequency.")

# Open the View Progress window
def open_progress_window():
    """Display a window showing the progress of all habits."""
    progress_window = Toplevel()
    progress_window.title("View Progress")
    progress_window.geometry("400x400")
    progress_window.config(bg=BACKGROUND_COLOR)

    tk.Label(
        progress_window, text="Weekly Progress", font=("Helvetica", 16), bg=BACKGROUND_COLOR, fg=TEXT_COLOR
    ).pack(pady=20)

    # Display habits and their progress
    for habit_name, details in habits.items():
        progress_label = f"{habit_name}: {len(details['completed'])}/{details['frequency']} completed"
        tk.Label(
            progress_window, text=progress_label, font=("Helvetica", 12), bg=BACKGROUND_COLOR, fg=TEXT_COLOR
        ).pack()

    # Display Running2.png in progress window (resize to 1/8)
    image_path = os.path.join(IMAGE_FOLDER_PATH, "Running2.png")
    if os.path.exists(image_path):
        img = tk.PhotoImage(file=image_path)
        img = img.subsample(8, 8)  # Resize to 1/8 of the original size

        # Label to display the image
        img_label = tk.Label(progress_window, image=img, bg=BACKGROUND_COLOR)
        img_label.image = img  # Store a reference to avoid garbage collection
        img_label.pack(pady=20)

    progress_window.mainloop()

# Open the Settings window
def open_settings_window():
    """Open a window for application settings."""
    settings_window = Toplevel()
    settings_window.title("Settings")
    settings_window.geometry("400x300")
    settings_window.config(bg=BACKGROUND_COLOR)

    tk.Label(
        settings_window, text="Settings", font=("Helvetica", 16), bg=BACKGROUND_COLOR, fg=TEXT_COLOR
    ).pack(pady=20)

    # Reminder Settings
    reminder_var = tk.BooleanVar(value=settings["reminder_enabled"])
    tk.Checkbutton(
        settings_window,
        text="Enable Daily Reminders",
        variable=reminder_var,
        bg=BACKGROUND_COLOR,
        fg=TEXT_COLOR,
        font=("Helvetica", 12),
        selectcolor=BUTTON_COLOR,
    ).pack(pady=10)

    # Notification Frequency
    notification_var = tk.StringVar(value=settings["notification_frequency"])
    tk.Label(
        settings_window, text="Notification Frequency:", font=("Helvetica", 12), bg=BACKGROUND_COLOR, fg=TEXT_COLOR
    ).pack(pady=10)
    notification_menu = tk.OptionMenu(
        settings_window,
        notification_var,
        "daily",
        "weekly",
        "monthly",
    )
    notification_menu.config(bg=BUTTON_COLOR, fg=BUTTON_TEXT_COLOR)
    notification_menu.pack(pady=10)

    # Save Settings Button
    def save_and_close():
        settings["reminder_enabled"] = reminder_var.get()
        settings["notification_frequency"] = notification_var.get()
        save_settings()
        messagebox.showinfo("Settings Saved", "Your settings have been saved successfully!")
        settings_window.destroy()

    create_button(settings_window, "Save Settings", save_and_close).pack(pady=20)

# Save settings to a file
def save_settings():
    """Save settings to a JSON file for persistence."""
    with open(SETTINGS_FILE, "w") as file:
        json.dump(settings, file, indent=4)

# Main program entry point
if __name__ == "__main__":
    create_main_window()